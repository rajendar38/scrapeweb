## Available kubectl plugins

This page is moved to https://krew.sigs.k8s.io/plugins.
